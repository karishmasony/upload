from django import forms
from .models import *
from .models import Csvfiles

class UploadDocumentForm(forms.Form):
    file = forms.FileField()

class new(forms.ModelForm):
    class Meta:
        model = Csvfiles
        fields = ('Class_name', 'Subject_name', 'Topic_name')
#
#
#
# class DocumentForm(forms.ModelForm):
#     class Meta:
#         model = Csvfiles
#         fields = '__all__'