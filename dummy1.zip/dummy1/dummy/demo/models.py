from django.db import models

class Class(models.Model):
    options = (('LKG', 'LKG'),('UKG', 'UKG'),('Class 1', 'Class 1'),('Class 2', 'Class 2'),('Class 3', 'Class 3'),('Class 4', 'Class 4'),('Class 5', 'Class 5'),
    ('Class 6', 'Class 6'), ('Class 7', 'Class 7'),('Class 8', 'Class 8'),('Class 9', 'Class 9'),('Class 10', 'Class 10'))
    name = models.CharField(max_length=200, choices=options, null=True)

    def __str__(self):
        return self.name
        

class Subject(models.Model):
    Class_name = models.ForeignKey(Class,max_length=200, null=True, on_delete=models.CASCADE)
    Sub_name = models.CharField(max_length=200, null=True)

    def __str__(self):
        return self.Sub_name

class Topic(models.Model):
    Class_name = models.ForeignKey(Class, max_length=200, null=True, on_delete=models.CASCADE, blank=False)
    Subject_name = models.ForeignKey(Subject, max_length=200, null=True, on_delete=models.CASCADE, blank=False)
    Topic_name = models.CharField(max_length=200, null=True, blank=False)
    # Number_of_questions = models.PositiveIntegerField()
    # Number_of_questions = models.IntegerField(verbose_name='Number of questions', null=True)
    # Each_question_marks = models.FloatField(verbose_name='Each question marks', null=True)

    def __str__(self):
        return self.Topic_name

class Question(models.Model):
    Class_name = models.ForeignKey(Class, max_length=200, null=True, on_delete=models.CASCADE)
    Subject_name = models.ForeignKey(Subject, max_length=200, null=True, on_delete=models.CASCADE)
    Topic_name = models.ForeignKey(Topic, max_length=200, null=True, on_delete=models.CASCADE)
    marks = models.PositiveIntegerField(default=0)
    Question_id = models.AutoField(primary_key=True)
    Question_text = models.CharField(max_length=500, blank=False, null=True)
    c1 = models.CharField(max_length=200, blank=False)
    c2 = models.CharField(max_length=200, blank=False)
    c3 = models.CharField(max_length=200, blank=False)
    c4 = models.CharField(max_length=200, blank=False)
    choice = (('c1','c1'),('c2','c2'),('c3','c3'),('c4','c4'))

    answer = models.CharField(max_length=200, choices=choice, null=True)

    def __str__(self):
        return self.Question_text


class SubjectiveQuestion(models.Model):
    Class_name = models.ForeignKey(Class,max_length=200, null=True, on_delete=models.CASCADE, blank=False)
    Subject_name = models.ForeignKey(Subject,max_length=200, null=True, on_delete=models.CASCADE, blank=False)
    Topic_name = models.ForeignKey(Topic,max_length=200, null=True,on_delete=models.CASCADE, blank=False)
    Subjective_Question = models.CharField(max_length=1024, null=True, blank=False)
    marks = models.PositiveIntegerField(default=0)
    
    def __str__(self):
        return self. Subjective_Question


class Csvfiles(models.Model):
    Class_name = models.ForeignKey(Class, max_length=200, null=True, on_delete=models.CASCADE, blank=False)
    Subject_name = models.ForeignKey(Subject, max_length=200, null=True, on_delete=models.CASCADE, blank=False)
    Topic_name = models.ForeignKey(Topic, max_length=200, null=True, on_delete=models.CASCADE, blank=False)
    qn = models.CharField(max_length=250, null=True)
    op1 = models.CharField(max_length=250, null=True)
    op2 = models.CharField(max_length=250, null=True)
    op3 = models.CharField(max_length=250, null=True)
    op4 = models.CharField(max_length=250, null=True)
    ans = models.CharField(max_length=250, null=True)

    def __str__(self):
        return self.qn

    


