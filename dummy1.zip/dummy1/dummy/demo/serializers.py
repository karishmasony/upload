from rest_framework import serializers
from .models import *

class Classserializer(serializers.ModelSerializer):
    class Meta:
        model = Class
        fields = ['id','name']

class Subjectserializer(serializers.ModelSerializer):
    class Meta:
        model = Subject
        fields = ['id', 'Class_name', 'Sub_name']

class Topicserializer(serializers.ModelSerializer):
    class Meta:
        model = Topic
        fields = ['id','Class_name', 'Subject_name', 'Topic_name']

class Questionserializer(serializers.ModelSerializer):
    class Meta:
        model = Question
        fields = ['id','Class_name', 'Subject_name', 'Topic_name', 'marks', 'Question_text', 'answer']

class Subjectiveserializer(serializers.ModelSerializer):
    class Meta:
        model = SubjectiveQuestion
        fields = ['id','Class_name', 'Subject_name', 'Topic_name', 'Subjective_Question', 'marks']