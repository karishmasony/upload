from django.urls import path
from .views import *
from . import views


urlpatterns = [
    path('class/', class_list, name='class'),
    path('classdetail/<int:pk>/', class_detail,name='class_detail'),
    path('subject/', subject_list, name='subject'),
    path('subjectdetail/<int:pk>/', subject_detail, name='subject_detail'),
    path('topic/', topic_list, name='topic'),
    path('topicdetail/<int:pk>/', topic_detail, name='topic_detail'),
    path('questions/', Question_list, name='questions'),
    path('questionsdetail/<int:pk>/', Question_detail, name='questions_detail'),
    path('', views.upload_doc, name='csvv'),
    # path('home/', views.new_views, name = 'new_views'),
    # path('upload/', views.uploadclass, name ='upload')

    # path('', views.home, name="home"),
    # path('products/', views.products, name='products'),
    # path('customer/<str:pk_test>/', views.customer, name="customer"),

    # path('create_order/<str:pk>/', views.createOrder, name="create_order"),
    # path('update_order/<str:pk>/', views.updateOrder, name="update_order"),
    # path('delete_order/<str:pk>/', views.deleteOrder, name="delete_order"),
]

