from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from .forms import UploadDocumentForm, new
from rest_framework.parsers import JSONParser
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view 
from rest_framework.response import Response
from rest_framework import status
import csv
from .models import *
from .serializers import *

# @csrf_exempt
# def class_list(request):
#
#     if  request.method == "GET":
#         classes = Class.objects.all()
#         serializer = Classserializer(classes, many=True)
#         return JsonResponse(serializer.data, safe=False)
#
#     elif request.method == "POST":
#         data = JSONParser().parse(request)
#         serializer =  Classserializer(data=data)
#
#         if serializer.is_valid():
#             serializer.save()
#             return JsonResponse(serializer.data, status=201)
#
#         return JsonResponse(serializer.errors, status=400)

# @csrf_exempt
# def class_detail(request, pk):
#     try:
#         classes = Class.objects.get(pk=pk)
#
#     except Class.DoesNotExist:
#
#         return HttpResponse(status=404)
#
#     if request.method == "GET":
#
#         serializer = Classserializer(classes)
#         return JsonResponse(serializer.data)
#
#     elif request.method == "PUT":
#
#         data = JSONParser().parse(request)
#         serializer = Classserializer(classes, data=data)
#         if serializer.is_valid():
#             serializer.save()
#             return JsonResponse(serializer.data)
#         return JsonResponse(serializer.errors, status=400)
#
#     elif request.method == "DELETE":
#
#         classes.delete()
#         return HttpResponse(status=204)
#

# //////////////////////////////////////
@api_view(['GET','POST'])
def class_list(request):

    if  request.method == "GET":
        classes = Class.objects.all()
        serializer = Classserializer(classes, many=True)
        return Response(serializer.data)

    elif request.method == "POST":
        # data = JSONParser().parse(request)
        serializer =  Classserializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET','PUT','DELETE'])
def class_detail(request, pk):
    try:
        classes = Class.objects.get(pk=pk)

    except Class.DoesNotExist:

        return HttpResponse(status=status.HTTP_400_BAD_REQUEST)

    if request.method == "GET":

        serializer = Classserializer(classes)
        return Response(serializer.data)

    elif request.method == "PUT":

        serializer =  Classserializer(classes, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == "DELETE":

        classes.delete()
        return Response(status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET','POST'])
def subject_list(request):

    if  request.method == "GET":
        subjects = Subject.objects.all()
        serializer = Subjectserializer(subjects, many=True)
        return Response(serializer.data)

    elif request.method == "POST":
        # data = JSONParser().parse(request)
        serializer =  Subjectserializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET','PUT','DELETE'])
def subject_detail(request, pk):
    try:
        subjects = Subject.objects.get(pk=pk)

    except Subject.DoesNotExist:

        return HttpResponse(status=status.HTTP_400_BAD_REQUEST)

    if request.method == "GET":

        serializer = Subjectserializer(subjects)
        return Response(serializer.data)

    elif request.method == "PUT":

        serializer = Subjectserializer(subjects, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == "DELETE":

        subjects.delete()
        return Response(status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET','POST'])
def topic_list(request):

    if  request.method == "GET":
        topics = Topic.objects.all()
        serializer = Topicserializer(topics, many=True)
        return Response(serializer.data)

    elif request.method == "POST":
        # data = JSONParser().parse(request)
        serializer =  Topicserializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET','PUT','DELETE'])
def topic_detail(request, pk):
    try:
        topics = Topic.objects.get(pk=pk)

    except Topic.DoesNotExist:

        return HttpResponse(status=status.HTTP_400_BAD_REQUEST)

    if request.method == "GET":

        serializer = Topicserializer(topics)
        return Response(serializer.data)

    elif request.method == "PUT":

        serializer =  Topicserializer(topics, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == "DELETE":

        topics.delete()
        return Response(status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET','POST'])
def Question_list(request):

    if  request.method == "GET":
        questions = Question.objects.all()
        serializer = Questionserializer(questions, many=True)
        return Response(serializer.data)

    elif request.method == "POST":
        # data = JSONParser().parse(request)
        serializer =  Questionserializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET','PUT','DELETE'])
def Question_detail(request, pk):
    try:
        questions = Question.objects.get(pk=pk)

    except Question.DoesNotExist:

        return HttpResponse(status=status.HTTP_400_BAD_REQUEST)

    if request.method == "GET":

        serializer = Questionserializer(questions)
        return Response(serializer.data)

    elif request.method == "PUT":

        serializer = Questionserializer(questions, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == "DELETE":

        questions.delete()
        return Response(status=status.HTTP_400_BAD_REQUEST)


def upload_doc(request):
    form = UploadDocumentForm()
    form1 = new()
    if request.method == 'POST':
        form1 = new(request.POST)
        if form1.is_valid():
            class_name = form1.cleaned_data['Class_name']
            subject_name = form1.cleaned_data['Subject_name']
            topic_name = form1.cleaned_data['Topic_name']
            class_namedetail = Class.objects.get(name=class_name)
            subject_namedetail = Subject.objects.get(Sub_name=subject_name)
            topic_namedetail = Topic.objects.get(Topic_name=topic_name)
            print('******')
            print(class_namedetail)
            form = UploadDocumentForm(request.POST, request.FILES)
            file1 = request.FILES.get('csv_file')
            decoded_file = file1.read().decode('utf-8').splitlines()
            reader = csv.DictReader(decoded_file)
            for row in reader:
                print(row)
                Csvfiles.objects.create(qn=row['question'],\
                                        op1=row['option1'],
                                        op2=row['option2'],
                                        op3=row['option3'],
                                        op4=row['option4'],
                                        ans=row['ans'],
                                        Class_name=class_namedetail,
                                        Subject_name=subject_namedetail,
                                        Topic_name=topic_namedetail)
            # with open(file1, mode='r') as csv_file:
            #     csv_reader = csv.DictReader(csv_file)
            #     for row in csv_reader:
            print('//////')
            print(file1)
            # Do not forget to add: request.FILES
            # if form.is_valid():
            return HttpResponse("Hello")
            # Do something with our files or simply save them
            # if saved, our files would be located in media/ folder under the project's base folder
            # form.save()
    # return HttpResponse(request, 'uploading/upload_doc.html', locals())
    return render(request, 'demo/upload_doc.html', {'form1':form1})


def new_views(request):
    context = {}
    form = new(request.POST or None)
    if form.is_valid():
        form.save()
    context['form'] = form
    return render(request, "demo/home.html", context)

# def uploadclass(request):
#     form = Class.objects.all()
#     print(form)
#     return render(request,'demo/Upload.html', {'forms':item})
